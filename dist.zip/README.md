# 🚀 Niraj's Portfolio Website

A modern, responsive personal portfolio website built with **React**, **Vite**, and **CSS**. Showcasing projects, skills, and experience as a Full Stack Web Developer.

## ✨ Features

- **5 Main Pages** - Home, About, Skills, Projects, and Contact
- **Modern UI** - Clean, responsive design optimized for all devices
- **Project Showcase** - Interactive project cards with detailed modals
- **Smooth Scrolling** - Scroll-to-top functionality for better navigation
- **Dark/Light Theme** - Theme switcher for user preference
- **Mobile Optimized** - Fully responsive across all screen sizes
- **Fast Performance** - Built with Vite for lightning-fast development and builds

## 🛠️ Tech Stack

- **Frontend Framework**: React 18.2
- **Build Tool**: Vite 5.1
- **Routing**: React Router DOM 6.22
- **Icons**: Lucide React
- **Styling**: CSS3
- **Package Manager**: npm

## 📁 Project Structure

```
src/
├── components/
│   ├── Layout/
│   │   ├── Navbar.jsx
│   │   └── Footer.jsx
│   └── UI/
│       ├── ProjectModal.jsx
│       ├── ScrollToTop.jsx
│       └── SectionHeader.jsx
├── pages/
│   ├── Home.jsx
│   ├── About.jsx
│   ├── Skills.jsx
│   ├── Projects.jsx
│   └── Contact.jsx
├── data/
│   └── portfolioData.js
├── App.jsx
├── main.jsx
└── index.css
```

## 🚀 Getting Started

### Prerequisites
- Node.js (v14 or higher)
- npm or yarn

### Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/portfolio-site.git
cd portfolio-site
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Open your browser and navigate to `http://localhost:5173`

### Build for Production

```bash
npm run build
```

This creates an optimized build in the `dist/` folder.

### Preview Production Build

```bash
npm run preview
```

## 📄 Pages Overview

- **Home** - Hero section with tech stack badges and featured projects
- **About** - Personal introduction and key highlights
- **Skills** - Languages and frameworks mastered
- **Projects** - Detailed project showcase with case studies
- **Contact** - Contact information and inquiry form

## 👤 Author

**Pandit Nirajkumar Balistar**  
Full Stack Web Developer

- Portfolio: [niraj0050](https://niraj0050.vercel.app/)
- GitHub: [Niraj0050](https://github.com/Niraj0050)
- LinkedIn: [in/niraj0050](www.linkedin.com/in/niraj0050)

## 📝 License

This project is open source and available under the MIT License - see the LICENSE file for details.

## 🤝 Contributing

Contributions are welcome! Feel free to fork this repository and submit pull requests for any improvements.

---

**Built with ❤️ by Pandit Nirajkumar Balistar**
