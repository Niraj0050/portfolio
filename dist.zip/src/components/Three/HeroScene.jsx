import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RotateCw, Sparkles, Eye, Compass } from 'lucide-react';

export default function HeroScene() {
  const mountRef = useRef(null);
  const [wireframeMode, setWireframeMode] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [activeNode, setActiveNode] = useState(null);
  const [webglSupported, setWebglSupported] = useState(true);

  // References for scene state
  const sceneRef = useRef(null);
  const coreMeshRef = useRef(null);
  const innerWireRef = useRef(null);
  const ringsRef = useRef([]);
  const satellitesRef = useRef([]);
  const mouseLightRef = useRef(null);
  const particlesRef = useRef(null);
  const pulseTriggerRef = useRef(0);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // 1. Check WebGL Availability
    try {
      const testCanvas = document.createElement('canvas');
      const gl = testCanvas.getContext('webgl') || testCanvas.getContext('experimental-webgl');
      if (!gl) {
        setWebglSupported(false);
        return;
      }
    } catch (e) {
      setWebglSupported(false);
      return;
    }

    // 2. Setup Scene, Camera, Renderer
    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || 600;

    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 0, 7.5);

    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: 'high-performance'
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.25;
    container.appendChild(renderer.domElement);

    // 3. Cinematic Lighting
    const ambientLight = new THREE.AmbientLight(0x0a0c16, 2.0);
    scene.add(ambientLight);

    // Key Light - Warm Amber / Electric Orange
    const keyLight = new THREE.DirectionalLight(0xff6b00, 3.8);
    keyLight.position.set(5, 6, 4);
    scene.add(keyLight);

    // Rim / Backlight - Luminous Cyber Cyan
    const rimLight = new THREE.DirectionalLight(0x00e5ff, 2.5);
    rimLight.position.set(-6, -4, -3);
    scene.add(rimLight);

    // Soft Fill Light
    const fillLight = new THREE.PointLight(0xffaa44, 2.0, 15);
    fillLight.position.set(0, -3, 2);
    scene.add(fillLight);

    // Interactive Cursor Point Light
    const mouseLight = new THREE.PointLight(0xff8c00, 3.5, 8);
    mouseLight.position.set(0, 0, 3);
    scene.add(mouseLight);
    mouseLightRef.current = mouseLight;

    // 4. Centerpiece Core: Hyper-Structure
    const coreGroup = new THREE.Group();
    scene.add(coreGroup);

    // Inner Solid Core - Deep Titanium / Copper Metallic Finish
    const coreGeo = new THREE.IcosahedronGeometry(1.6, 2);
    const coreMat = new THREE.MeshStandardMaterial({
      color: 0x12141c,
      metalness: 0.92,
      roughness: 0.18,
      emissive: 0x221105,
      emissiveIntensity: 0.4,
      flatShading: true
    });
    const coreMesh = new THREE.Mesh(coreGeo, coreMat);
    coreGroup.add(coreMesh);
    coreMeshRef.current = coreMesh;

    // Inner Glowing Wireframe Core
    const wireGeo = new THREE.IcosahedronGeometry(1.64, 2);
    const wireMat = new THREE.MeshBasicMaterial({
      color: 0xff6b00,
      wireframe: true,
      transparent: true,
      opacity: 0.45
    });
    const innerWire = new THREE.Mesh(wireGeo, wireMat);
    coreGroup.add(innerWire);
    innerWireRef.current = innerWire;

    // Center Quantum Seed (Small inner glowing sphere)
    const seedGeo = new THREE.OctahedronGeometry(0.7, 0);
    const seedMat = new THREE.MeshBasicMaterial({
      color: 0xffaa00,
      wireframe: true
    });
    const seedMesh = new THREE.Mesh(seedGeo, seedMat);
    coreGroup.add(seedMesh);

    // 5. Concentric Gyroscopic Rings (Gimbal data rings)
    const rings = [];
    const ringConfigs = [
      { radius: 2.3, tube: 0.022, color: 0xff6b00, rotX: 0.5, rotY: 0.2 },
      { radius: 2.7, tube: 0.018, color: 0xf59e0b, rotX: -0.4, rotY: 0.6 },
      { radius: 3.1, tube: 0.014, color: 0x00e5ff, rotX: 0.8, rotY: -0.3 }
    ];

    ringConfigs.forEach((cfg) => {
      const ringGeo = new THREE.TorusGeometry(cfg.radius, cfg.tube, 16, 100);
      const ringMat = new THREE.MeshStandardMaterial({
        color: cfg.color,
        emissive: cfg.color,
        emissiveIntensity: 0.6,
        metalness: 0.9,
        roughness: 0.2
      });
      const ring = new THREE.Mesh(ringGeo, ringMat);
      ring.rotation.x = cfg.rotX;
      ring.rotation.y = cfg.rotY;
      coreGroup.add(ring);
      rings.push(ring);
    });
    ringsRef.current = rings;

    // 6. Orbital Satellites (Representing 4 pillars: Frontend, Backend, Database, Machine Learning)
    const satellites = [];
    const satelliteData = [
      { name: 'Frontend (React.js)', color: 0x00e5ff, dist: 2.5, speed: 0.8, angle: 0 },
      { name: 'Backend (PHP & Node)', color: 0xffaa00, dist: 2.9, speed: -0.6, angle: Math.PI * 0.5 },
      { name: 'Database (MySQL)', color: 0xff5500, dist: 3.3, speed: 0.5, angle: Math.PI },
      { name: 'Data / ML (Python)', color: 0x10b981, dist: 2.7, speed: -0.7, angle: Math.PI * 1.5 }
    ];

    satelliteData.forEach((sat) => {
      const satGroup = new THREE.Group();
      
      // Node sphere
      const satGeo = new THREE.SphereGeometry(0.12, 16, 16);
      const satMat = new THREE.MeshStandardMaterial({
        color: sat.color,
        emissive: sat.color,
        emissiveIntensity: 1.2,
        roughness: 0.1
      });
      const satMesh = new THREE.Mesh(satGeo, satMat);
      satGroup.add(satMesh);

      // Glow halo ring
      const haloGeo = new THREE.RingGeometry(0.15, 0.22, 24);
      const haloMat = new THREE.MeshBasicMaterial({
        color: sat.color,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.7
      });
      const halo = new THREE.Mesh(haloGeo, haloMat);
      satGroup.add(halo);

      coreGroup.add(satGroup);
      satellites.push({ group: satGroup, halo, config: sat });
    });
    satellitesRef.current = satellites;

    // 7. Ambient Particle Field (Quantum dust)
    const particleCount = 650;
    const particleGeo = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);
    const particleColors = new Float32Array(particleCount * 3);

    const cOrange = new THREE.Color(0xff6b00);
    const cAmber = new THREE.Color(0xf59e0b);
    const cCyan = new THREE.Color(0x00e5ff);

    for (let i = 0; i < particleCount; i++) {
      const idx = i * 3;
      const r = 3.2 + Math.random() * 5.0;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);

      particlePositions[idx] = r * Math.sin(phi) * Math.cos(theta);
      particlePositions[idx + 1] = r * Math.sin(phi) * Math.sin(theta);
      particlePositions[idx + 2] = r * Math.cos(phi);

      const color = i % 3 === 0 ? cOrange : (i % 3 === 1 ? cAmber : cCyan);
      particleColors[idx] = color.r;
      particleColors[idx + 1] = color.g;
      particleColors[idx + 2] = color.b;
    }

    particleGeo.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    particleGeo.setAttribute('color', new THREE.BufferAttribute(particleColors, 3));

    const particleMat = new THREE.PointsMaterial({
      size: 0.045,
      vertexColors: true,
      transparent: true,
      opacity: 0.75,
      blending: THREE.AdditiveBlending
    });

    const particles = new THREE.Points(particleGeo, particleMat);
    scene.add(particles);
    particlesRef.current = particles;

    // 8. Mouse Tracking & Drag Interactivity
    const mouse = { x: 0, y: 0, targetX: 0, targetY: 0 };
    let isDragging = false;
    let prevMousePos = { x: 0, y: 0 };
    let dragVelocity = { x: 0, y: 0 };

    const handleMouseMove = (e) => {
      const rect = container.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const y = -(((e.clientY - rect.top) / rect.height) * 2 - 1);
      mouse.targetX = x;
      mouse.targetY = y;

      if (isDragging) {
        const deltaX = e.clientX - prevMousePos.x;
        const deltaY = e.clientY - prevMousePos.y;
        dragVelocity.x = deltaX * 0.006;
        dragVelocity.y = deltaY * 0.006;
        prevMousePos = { x: e.clientX, y: e.clientY };
      }
    };

    const handleMouseDown = (e) => {
      isDragging = true;
      prevMousePos = { x: e.clientX, y: e.clientY };
    };

    const handleMouseUp = () => {
      isDragging = false;
    };

    const handleTouchStart = (e) => {
      if (e.touches.length === 1) {
        isDragging = true;
        prevMousePos = { x: e.touches[0].clientX, y: e.touches[0].clientY };
      }
    };

    const handleTouchMove = (e) => {
      if (isDragging && e.touches.length === 1) {
        const deltaX = e.touches[0].clientX - prevMousePos.x;
        const deltaY = e.touches[0].clientY - prevMousePos.y;
        dragVelocity.x = deltaX * 0.006;
        dragVelocity.y = deltaY * 0.006;
        prevMousePos = { x: e.touches[0].clientX, y: e.touches[0].clientY };
      }
    };

    const handleTouchEnd = () => {
      isDragging = false;
    };

    container.addEventListener('mousemove', handleMouseMove);
    container.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);
    container.addEventListener('touchstart', handleTouchStart, { passive: true });
    container.addEventListener('touchmove', handleTouchMove, { passive: true });
    window.addEventListener('touchend', handleTouchEnd);

    // 9. Resize Handling
    const handleResize = () => {
      if (!container) return;
      const newWidth = container.clientWidth;
      const newHeight = container.clientHeight || 600;
      camera.aspect = newWidth / newHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(newWidth, newHeight);
    };
    window.addEventListener('resize', handleResize);

    // 10. Visibility Observer (Pause rendering when off-screen for battery/GPU efficiency)
    let isVisible = true;
    const observer = new IntersectionObserver(([entry]) => {
      isVisible = entry.isIntersecting;
    }, { threshold: 0.1 });
    observer.observe(container);

    // 11. Render Animation Loop
    let animationFrameId;
    let clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      if (!isVisible) return;

      const elapsedTime = clock.getElapsedTime();

      // Mouse position smoothing (lerp)
      mouse.x += (mouse.targetX - mouse.x) * 0.06;
      mouse.y += (mouse.targetY - mouse.y) * 0.06;

      // Update interactive point light
      if (mouseLightRef.current) {
        mouseLightRef.current.position.x = mouse.x * 4.5;
        mouseLightRef.current.position.y = mouse.y * 3.5;
        mouseLightRef.current.position.z = 3.5;
      }

      // Parallax camera movement
      camera.position.x = mouse.x * 0.8;
      camera.position.y = mouse.y * 0.6;
      camera.lookAt(0, 0, 0);

      // Core rotations + Drag damping
      if (isDragging) {
        coreGroup.rotation.y += dragVelocity.x;
        coreGroup.rotation.x += dragVelocity.y;
      } else {
        dragVelocity.x *= 0.94;
        dragVelocity.y *= 0.94;
        coreGroup.rotation.y += dragVelocity.x + 0.004;
        coreGroup.rotation.x += dragVelocity.y + 0.002;
      }

      // Pulse wave effect
      if (pulseTriggerRef.current > 0) {
        pulseTriggerRef.current -= 0.03;
        const scale = 1 + Math.sin(pulseTriggerRef.current * Math.PI) * 0.25;
        coreMesh.scale.set(scale, scale, scale);
        innerWire.scale.set(scale * 1.03, scale * 1.03, scale * 1.03);
      } else {
        coreMesh.scale.set(1, 1, 1);
        innerWire.scale.set(1, 1, 1);
      }

      // Inner wireframe counter-rotation
      if (innerWireRef.current) {
        innerWireRef.current.rotation.y -= 0.006;
        innerWireRef.current.rotation.z += 0.003;
      }

      // Small seed rotation
      seedMesh.rotation.x += 0.015;
      seedMesh.rotation.y += 0.02;

      // Gyroscopic rings rotations
      if (ringsRef.current.length === 3) {
        ringsRef.current[0].rotation.z += 0.008;
        ringsRef.current[1].rotation.x += 0.006;
        ringsRef.current[2].rotation.y += 0.007;
      }

      // Orbital Satellites Revolution
      satellitesRef.current.forEach((sat) => {
        const angle = sat.config.angle + elapsedTime * sat.config.speed;
        const x = Math.cos(angle) * sat.config.dist;
        const z = Math.sin(angle) * sat.config.dist;
        const y = Math.sin(elapsedTime * 1.5 + sat.config.dist) * 0.5;

        sat.group.position.set(x, y, z);
        sat.halo.lookAt(camera.position);
      });

      // Particle Field gentle rotation
      if (particlesRef.current) {
        particlesRef.current.rotation.y = elapsedTime * 0.025;
        particlesRef.current.rotation.x = Math.sin(elapsedTime * 0.015) * 0.08;
      }

      renderer.render(scene, camera);
    };

    animate();

    // 12. Cleanup
    return () => {
      observer.disconnect();
      cancelAnimationFrame(animationFrameId);
      container.removeEventListener('mousemove', handleMouseMove);
      container.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
      container.removeEventListener('touchstart', handleTouchStart);
      container.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleTouchEnd);
      window.removeEventListener('resize', handleResize);

      // Clean Three.js resources
      if (renderer.domElement && container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      coreGeo.dispose();
      coreMat.dispose();
      wireGeo.dispose();
      wireMat.dispose();
      seedGeo.dispose();
      seedMat.dispose();
      particleGeo.dispose();
      particleMat.dispose();
      renderer.dispose();
    };
  }, []);

  // Wireframe toggle effect
  useEffect(() => {
    if (coreMeshRef.current) {
      coreMeshRef.current.material.wireframe = wireframeMode;
    }
  }, [wireframeMode]);

  // Trigger energy pulse
  const triggerPulse = () => {
    pulseTriggerRef.current = 1.0;
  };

  // Reset core orientation
  const resetOrientation = () => {
    if (sceneRef.current) {
      const core = sceneRef.current.children.find(c => c.type === 'Group');
      if (core) {
        core.rotation.set(0, 0, 0);
      }
    }
  };

  if (!webglSupported) {
    return (
      <div 
        style={{
          width: '100%',
          height: '100%',
          minHeight: '480px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: 'radial-gradient(circle at center, rgba(255, 107, 0, 0.15) 0%, rgba(7, 8, 12, 0.95) 75%)',
          borderRadius: 'var(--radius-lg)',
          border: '1px solid var(--border-color)',
          textAlign: 'center',
          padding: '2rem'
        }}
      >
        <div>
          <div style={{ width: '64px', height: '64px', margin: '0 auto 1.5rem auto', borderRadius: '50%', background: 'rgba(255,107,0,0.1)', border: '1px solid var(--border-accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--accent-orange)' }}>
            <Compass size={32} />
          </div>
          <h3 style={{ fontSize: '1.4rem', marginBottom: '0.5rem' }}>3D Computational Core</h3>
          <p style={{ color: 'var(--text-secondary)', maxWidth: '380px', margin: '0 auto', fontSize: '0.9rem' }}>
            Interactive 3D view is optimized for modern WebGL browsers. Full-stack architecture, clean code, and database logic active.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div 
      style={{
        position: 'relative',
        width: '100%',
        height: '100%',
        minHeight: '520px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        cursor: 'grab'
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Three.js Canvas Container */}
      <div 
        ref={mountRef} 
        style={{ 
          width: '100%', 
          height: '100%', 
          position: 'absolute', 
          inset: 0,
          outline: 'none'
        }} 
      />

      {/* Floating 3D HUD Controls */}
      <div
        style={{
          position: 'absolute',
          bottom: '1.5rem',
          right: '1.5rem',
          display: 'flex',
          gap: '0.6rem',
          zIndex: 10,
          background: 'rgba(13, 16, 24, 0.75)',
          backdropFilter: 'blur(16px)',
          border: '1px solid var(--border-color)',
          padding: '0.4rem 0.6rem',
          borderRadius: 'var(--radius-full)',
          boxShadow: '0 10px 25px rgba(0,0,0,0.5)'
        }}
      >
        <button
          onClick={triggerPulse}
          title="Pulse Core Energy Wave"
          aria-label="Pulse Core Energy Wave"
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '0.35rem',
            padding: '0.4rem 0.75rem',
            borderRadius: 'var(--radius-full)',
            background: 'rgba(255, 107, 0, 0.12)',
            border: '1px solid var(--border-accent)',
            color: 'var(--accent-orange)',
            fontSize: '0.78rem',
            fontWeight: 600
          }}
        >
          <Sparkles size={14} />
          <span>Pulse</span>
        </button>

        <button
          onClick={() => setWireframeMode(!wireframeMode)}
          title="Toggle Wireframe / Solid Geometry"
          aria-label="Toggle Wireframe"
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '0.35rem',
            padding: '0.4rem 0.75rem',
            borderRadius: 'var(--radius-full)',
            background: wireframeMode ? 'var(--accent-gradient)' : 'rgba(255, 255, 255, 0.05)',
            color: wireframeMode ? '#07080c' : 'var(--text-secondary)',
            fontSize: '0.78rem',
            fontWeight: 600
          }}
        >
          <Eye size={14} />
          <span>{wireframeMode ? 'Solid' : 'Wireframe'}</span>
        </button>

        <button
          onClick={resetOrientation}
          title="Reset 3D Core Orientation"
          aria-label="Reset Orientation"
          style={{
            display: 'flex',
            alignItems: 'center',
            padding: '0.4rem 0.5rem',
            borderRadius: 'var(--radius-full)',
            background: 'rgba(255, 255, 255, 0.05)',
            color: 'var(--text-secondary)',
            fontSize: '0.78rem'
          }}
        >
          <RotateCw size={14} />
        </button>
      </div>

      {/* Floating Status Pill & Drag Guide */}
      <div
        style={{
          position: 'absolute',
          top: '1.25rem',
          left: '1.25rem',
          display: 'flex',
          alignItems: 'center',
          gap: '0.6rem',
          zIndex: 10,
          background: 'rgba(13, 16, 24, 0.65)',
          backdropFilter: 'blur(12px)',
          border: '1px solid var(--border-color)',
          padding: '0.35rem 0.9rem',
          borderRadius: 'var(--radius-full)',
          fontSize: '0.78rem',
          color: 'var(--text-secondary)'
        }}
      >
        <span className="status-beacon"></span>
        <span style={{ fontFamily: 'var(--font-heading)', fontWeight: 600, color: 'var(--text-primary)' }}>
          Real-time Three.js 60FPS
        </span>
        <span style={{ color: 'var(--text-muted)' }}>| Drag to inspect</span>
      </div>
    </div>
  );
}
