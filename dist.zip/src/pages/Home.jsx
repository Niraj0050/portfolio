import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { 
  ArrowRight, 
  Code2, 
  Database, 
  Layout, 
  Sparkles, 
  Terminal, 
  FileText, 
  CheckCircle, 
  ExternalLink, 
  Github, 
  ChevronDown, 
  Layers, 
  Cpu, 
  Server,
  Zap,
  Globe
} from 'lucide-react';
import SectionHeader from '../components/UI/SectionHeader';
import ProjectModal from '../components/UI/ProjectModal';
import HeroScene from '../components/Three/HeroScene';
import { Database3DView, WebPrism3DView, NeuralSurface3DView } from '../components/Three/Project3DViews';
import { personalData, projectsData, skillsData } from '../data/portfolioData';

export default function Home() {
  const [selectedProject, setSelectedProject] = useState(null);
  const [hoveredProject, setHoveredProject] = useState(null);

  const scrollToProjects = () => {
    const el = document.getElementById('featured-projects');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="animate-fade-in" style={{ position: 'relative', zIndex: 1 }}>
      
      {/* SECTION 1: HERO BANNER (Full-Screen 3D Experience) */}
      <section 
        style={{ 
          minHeight: 'calc(100vh - 80px)', 
          display: 'flex', 
          alignItems: 'center', 
          position: 'relative',
          padding: '2.5rem 0 4rem 0',
          overflow: 'hidden'
        }}
      >
        <div className="container">
          <div 
            style={{ 
              display: 'grid', 
              gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', 
              gap: '2.5rem', 
              alignItems: 'center' 
            }}
          >
            {/* Left Column: Greeting, Headline & Authenticity */}
            <div style={{ zIndex: 2 }}>
              
              {/* Status Pill */}
              <div 
                className="section-badge" 
                style={{ 
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '0.65rem',
                  padding: '0.45rem 1.1rem',
                  marginBottom: '1.25rem' 
                }}
              >
                <span className="status-beacon"></span>
                <span style={{ fontWeight: 600, color: 'var(--text-primary)', letterSpacing: '0.5px' }}>
                  Full Stack Developer
                </span>
                <span style={{ color: 'var(--accent-orange)' }}>• Open for Hiring</span>
              </div>

              {/* High-Impact Headline */}
              <h1 
                style={{ 
                  fontSize: 'clamp(2.75rem, 5.5vw, 4.4rem)', 
                  fontWeight: 800, 
                  marginBottom: '1.25rem', 
                  lineHeight: '1.1',
                  letterSpacing: '-0.03em'
                }}
              >
                Crafting Scalable <br />
                <span className="gradient-text">Interactive 3D</span> & Web Systems.
              </h1>

              {/* Authentic Introduction */}
              <p 
                style={{ 
                  color: 'var(--text-secondary)', 
                  fontSize: '1.15rem', 
                  marginBottom: '2.25rem', 
                  lineHeight: '1.75', 
                  maxWidth: '560px' 
                }}
              >
                Hi, I'm <strong style={{ color: 'var(--text-primary)' }}>{personalData.name}</strong>. 
                A Full-Stack Developer and B.Sc. Computer Science graduate specialized in building robust 
                systems with <strong style={{ color: '#fff' }}>React.js</strong>, <strong style={{ color: '#fff' }}>PHP</strong>, <strong style={{ color: '#fff' }}>Python</strong>, and <strong style={{ color: '#fff' }}>MySQL</strong>.
              </p>

              {/* Action Buttons */}
              <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', marginBottom: '3rem' }}>
                <button 
                  onClick={scrollToProjects} 
                  className="btn btn-primary"
                  style={{ cursor: 'pointer' }}
                >
                  <span>Explore My Work</span>
                  <ArrowRight size={18} />
                </button>

                <NavLink to="/contact" className="btn btn-outline">
                  <span>Get In Touch</span>
                </NavLink>

                <NavLink to="/about" className="btn btn-cyber">
                  <span>View Background</span>
                </NavLink>
              </div>

              {/* Verified Metrics Counter Strip */}
              <div 
                style={{ 
                  display: 'grid', 
                  gridTemplateColumns: 'repeat(3, auto)', 
                  gap: '2rem', 
                  paddingTop: '1.75rem', 
                  borderTop: '1px solid var(--border-color)',
                  maxWidth: '460px'
                }}
              >
                <div>
                  <div style={{ fontSize: '1.85rem', fontWeight: 800, color: 'var(--accent-orange)', fontFamily: 'var(--font-heading)' }}>
                    3+
                  </div>
                  <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                    Engineered Projects
                  </div>
                </div>

                <div>
                  <div style={{ fontSize: '1.85rem', fontWeight: 800, color: 'var(--accent-amber)', fontFamily: 'var(--font-heading)' }}>
                    2026
                  </div>
                  <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                    B.Sc. CS Degree
                  </div>
                </div>

                <div>
                  <div style={{ fontSize: '1.85rem', fontWeight: 800, color: 'var(--accent-cyan)', fontFamily: 'var(--font-heading)' }}>
                    60 FPS
                  </div>
                  <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                    Interactive WebGL
                  </div>
                </div>
              </div>

            </div>

            {/* Right Column: Genuine 3D Centerpiece Hero Scene */}
            <div 
              style={{ 
                position: 'relative', 
                height: '560px', 
                width: '100%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}
            >
              <HeroScene />
            </div>

          </div>
        </div>

        {/* Scroll Indicator */}
        <div 
          onClick={scrollToProjects}
          style={{
            position: 'absolute',
            bottom: '1rem',
            left: '50%',
            transform: 'translateX(-50%)',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            gap: '0.35rem',
            color: 'var(--text-muted)',
            fontSize: '0.75rem',
            textTransform: 'uppercase',
            letterSpacing: '1px',
            cursor: 'pointer',
            zIndex: 10,
            transition: 'var(--transition-fast)'
          }}
        >
          <span>Scroll Down</span>
          <ChevronDown size={16} className="animate-float" color="var(--accent-orange)" />
        </div>
      </section>

      {/* SECTION 2: ABOUT CAPABILITIES & APPROACH */}
      <section 
        className="section" 
        style={{ 
          background: 'var(--bg-secondary)', 
          borderTop: '1px solid var(--border-color)', 
          borderBottom: '1px solid var(--border-color)' 
        }}
      >
        <div className="container">
          <SectionHeader
            badge="Engineering Philosophy"
            title="Full-Stack Capabilities & Approach"
            subtitle="Bridging modern interactive interfaces with scalable relational backends, structured schemas, and clean software architecture."
          />

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(290px, 1fr))', gap: '2rem' }}>
            
            {/* Frontend Card */}
            <div className="glass-card" style={{ padding: '2.5rem 2rem' }}>
              <div 
                style={{ 
                  width: '52px', 
                  height: '52px', 
                  borderRadius: 'var(--radius-md)', 
                  background: 'rgba(0, 229, 255, 0.12)', 
                  border: '1px solid var(--border-accent-cyan)',
                  color: 'var(--accent-cyan)', 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'center', 
                  marginBottom: '1.5rem' 
                }}
              >
                <Layout size={26} />
              </div>
              <h3 style={{ fontSize: '1.35rem', marginBottom: '0.85rem' }}>Interactive Frontend</h3>
              <p style={{ color: 'var(--text-secondary)', fontSize: '0.94rem', lineHeight: '1.7', marginBottom: '1.25rem' }}>
                Developing single-page React 18 applications, modular component trees, responsive layouts, 
                and genuine Three.js real-time 3D experiences.
              </p>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.45rem' }}>
                {['React.js', 'Three.js', 'JavaScript (ES6+)', 'HTML5/CSS3'].map((item) => (
                  <span key={item} className="tech-tag" style={{ fontSize: '0.75rem' }}>{item}</span>
                ))}
              </div>
            </div>

            {/* Backend & DB Card */}
            <div className="glass-card" style={{ padding: '2.5rem 2rem' }}>
              <div 
                style={{ 
                  width: '52px', 
                  height: '52px', 
                  borderRadius: 'var(--radius-md)', 
                  background: 'rgba(255, 107, 0, 0.12)', 
                  border: '1px solid var(--border-accent)',
                  color: 'var(--accent-orange)', 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'center', 
                  marginBottom: '1.5rem' 
                }}
              >
                <Server size={26} />
              </div>
              <h3 style={{ fontSize: '1.35rem', marginBottom: '0.85rem' }}>Backend & Schemas</h3>
              <p style={{ color: 'var(--text-secondary)', fontSize: '0.94rem', lineHeight: '1.7', marginBottom: '1.25rem' }}>
                Architecting server-side PHP scripts, Node.js REST services, and robust relational 
                MySQL databases with normalized relational tables and index optimization.
              </p>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.45rem' }}>
                {['PHP', 'MySQL', 'Node.js', 'REST APIs', 'PostgreSQL'].map((item) => (
                  <span key={item} className="tech-tag" style={{ fontSize: '0.75rem' }}>{item}</span>
                ))}
              </div>
            </div>

            {/* Python & ML Card */}
            <div className="glass-card" style={{ padding: '2.5rem 2rem' }}>
              <div 
                style={{ 
                  width: '52px', 
                  height: '52px', 
                  borderRadius: 'var(--radius-md)', 
                  background: 'rgba(245, 158, 11, 0.12)', 
                  border: '1px solid rgba(245, 158, 11, 0.35)',
                  color: 'var(--accent-amber)', 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'center', 
                  marginBottom: '1.5rem' 
                }}
              >
                <Cpu size={26} />
              </div>
              <h3 style={{ fontSize: '1.35rem', marginBottom: '0.85rem' }}>Data & Systems</h3>
              <p style={{ color: 'var(--text-secondary)', fontSize: '0.94rem', lineHeight: '1.7', marginBottom: '1.25rem' }}>
                Building standalone Python desktop GUIs with Tkinter, alongside data analysis, feature engineering, 
                and predictive machine learning pipelines using Scikit-Learn.
              </p>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.45rem' }}>
                {['Python', 'Tkinter', 'Pandas', 'Scikit-Learn', 'Matplotlib'].map((item) => (
                  <span key={item} className="tech-tag" style={{ fontSize: '0.75rem' }}>{item}</span>
                ))}
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* SECTION 3: SELECTED PROJECTS — INTERACTIVE 3D PRESENTATION */}
      <section id="featured-projects" className="section">
        <div className="container">
          <SectionHeader
            badge="Curated Showcase"
            title="Selected Engineering Projects"
            subtitle="Explore real-world software applications built across web engineering, database architecture, and machine learning domains."
          />

          <div style={{ display: 'flex', flexDirection: 'column', gap: '3.5rem' }}>
            
            {/* PROJECT 1: Student Record Management System */}
            <div 
              className="glass-card" 
              style={{ 
                padding: '0', 
                overflow: 'hidden',
                border: '1px solid var(--border-color)',
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
                alignItems: 'center'
              }}
              onMouseEnter={() => setHoveredProject('student-record')}
              onMouseLeave={() => setHoveredProject(null)}
            >
              {/* 3D Interactive Viewport */}
              <div 
                style={{ 
                  background: 'radial-gradient(circle at center, rgba(255, 107, 0, 0.08) 0%, rgba(13, 16, 24, 0.95) 75%)',
                  padding: '2rem',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  minHeight: '320px',
                  borderRight: '1px solid var(--border-color)'
                }}
              >
                <div style={{ width: '100%', height: '240px' }}>
                  <Database3DView isHovered={hoveredProject === 'student-record'} />
                </div>
                <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginTop: '0.5rem', fontFamily: 'var(--font-heading)' }}>
                  Interactive 3D Relational Database Monolith • Move cursor to inspect
                </span>
              </div>

              {/* Project Details */}
              <div style={{ padding: '2.75rem 2.5rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1rem' }}>
                  <span className="tech-tag" style={{ background: 'rgba(255, 107, 0, 0.12)', color: 'var(--accent-orange)', borderColor: 'var(--border-accent)', fontWeight: 600 }}>
                    Desktop Applications
                  </span>
                  <span style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>Role: Lead Developer</span>
                </div>

                <h3 style={{ fontSize: '1.75rem', marginBottom: '1rem' }}>
                  Student Record Management System
                </h3>

                <p style={{ color: 'var(--text-secondary)', fontSize: '0.98rem', lineHeight: '1.7', marginBottom: '1.5rem' }}>
                  A desktop database application engineered in Python with Tkinter and MySQL to manage academic logs, 
                  enrollments, and student information. Features real-time queries, search-by-ID filters, and ACID transaction safety.
                </p>

                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem', marginBottom: '2rem' }}>
                  {['Python', 'Tkinter', 'MySQL', 'Relational Schema', 'CRUD Operations'].map((tag) => (
                    <span key={tag} className="tech-tag">{tag}</span>
                  ))}
                </div>

                <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
                  <button
                    onClick={() => setSelectedProject(projectsData[0])}
                    className="btn btn-outline"
                    style={{ padding: '0.7rem 1.4rem', fontSize: '0.9rem' }}
                  >
                    <span>View Architecture</span>
                    <ArrowRight size={16} />
                  </button>

                  <a
                    href="https://github.com/niraj0050/Student-Record-Management-System"
                    target="_blank"
                    rel="noreferrer"
                    className="btn btn-primary"
                    style={{ padding: '0.7rem 1.4rem', fontSize: '0.9rem' }}
                  >
                    <Github size={17} />
                    <span>View GitHub Source</span>
                  </a>
                </div>
              </div>
            </div>

            {/* PROJECT 2: Personal Portfolio Website */}
            <div 
              className="glass-card" 
              style={{ 
                padding: '0', 
                overflow: 'hidden',
                border: '1px solid var(--border-color)',
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
                alignItems: 'center'
              }}
              onMouseEnter={() => setHoveredProject('portfolio-website')}
              onMouseLeave={() => setHoveredProject(null)}
            >
              {/* Project Details (Left for asymmetric editorial layout) */}
              <div style={{ padding: '2.75rem 2.5rem', order: 2 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1rem' }}>
                  <span className="tech-tag" style={{ background: 'rgba(0, 229, 255, 0.12)', color: 'var(--accent-cyan)', borderColor: 'var(--border-accent-cyan)', fontWeight: 600 }}>
                    Web Applications
                  </span>
                  <span style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>Role: Creative Developer & UI/UX</span>
                </div>

                <h3 style={{ fontSize: '1.75rem', marginBottom: '1rem' }}>
                  Interactive 3D Portfolio Platform
                </h3>

                <p style={{ color: 'var(--text-secondary)', fontSize: '0.98rem', lineHeight: '1.7', marginBottom: '1.5rem' }}>
                  A high-performance personal developer portfolio built with React 18, Three.js real-time WebGL rendering, 
                  glassmorphism styling, and mobile-first responsive architecture. Deployed globally with zero-downtime CI/CD.
                </p>

                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem', marginBottom: '2rem' }}>
                  {['React.js', 'Three.js', 'Vite', 'Glassmorphism', 'WebGL 60FPS'].map((tag) => (
                    <span key={tag} className="tech-tag">{tag}</span>
                  ))}
                </div>

                <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
                  <button
                    onClick={() => setSelectedProject(projectsData[1])}
                    className="btn btn-outline"
                    style={{ padding: '0.7rem 1.4rem', fontSize: '0.9rem' }}
                  >
                    <span>View Case Study</span>
                    <ArrowRight size={16} />
                  </button>

                  <a
                    href="https://github.com/niraj0050/portfolio"
                    target="_blank"
                    rel="noreferrer"
                    className="btn btn-primary"
                    style={{ padding: '0.7rem 1.4rem', fontSize: '0.9rem' }}
                  >
                    <Github size={17} />
                    <span>View Repository</span>
                  </a>
                </div>
              </div>

              {/* 3D Interactive Viewport */}
              <div 
                style={{ 
                  background: 'radial-gradient(circle at center, rgba(0, 229, 255, 0.08) 0%, rgba(13, 16, 24, 0.95) 75%)',
                  padding: '2rem',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  minHeight: '320px',
                  borderLeft: '1px solid var(--border-color)',
                  order: 1
                }}
              >
                <div style={{ width: '100%', height: '240px' }}>
                  <WebPrism3DView isHovered={hoveredProject === 'portfolio-website'} />
                </div>
                <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginTop: '0.5rem', fontFamily: 'var(--font-heading)' }}>
                  Interactive 3D Glass Viewport Prism • Hover & tilt perspective
                </span>
              </div>
            </div>

            {/* PROJECT 3: Machine Learning Mini Project */}
            <div 
              className="glass-card" 
              style={{ 
                padding: '0', 
                overflow: 'hidden',
                border: '1px solid var(--border-color)',
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
                alignItems: 'center'
              }}
              onMouseEnter={() => setHoveredProject('ml-mini-project')}
              onMouseLeave={() => setHoveredProject(null)}
            >
              {/* 3D Interactive Viewport */}
              <div 
                style={{ 
                  background: 'radial-gradient(circle at center, rgba(245, 158, 11, 0.08) 0%, rgba(13, 16, 24, 0.95) 75%)',
                  padding: '2rem',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  minHeight: '320px',
                  borderRight: '1px solid var(--border-color)'
                }}
              >
                <div style={{ width: '100%', height: '240px' }}>
                  <NeuralSurface3DView isHovered={hoveredProject === 'ml-mini-project'} />
                </div>
                <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginTop: '0.5rem', fontFamily: 'var(--font-heading)' }}>
                  Interactive 3D Loss Surface Topology • Dynamic vertex simulation
                </span>
              </div>

              {/* Project Details */}
              <div style={{ padding: '2.75rem 2.5rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1rem' }}>
                  <span className="tech-tag" style={{ background: 'rgba(245, 158, 11, 0.12)', color: 'var(--accent-amber)', borderColor: 'rgba(245, 158, 11, 0.35)', fontWeight: 600 }}>
                    Machine Learning
                  </span>
                  <span style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>Role: ML Pipeline Developer</span>
                </div>

                <h3 style={{ fontSize: '1.75rem', marginBottom: '1rem' }}>
                  Machine Learning Mini Project
                </h3>

                <p style={{ color: 'var(--text-secondary)', fontSize: '0.98rem', lineHeight: '1.7', marginBottom: '1.5rem' }}>
                  End-to-end data preprocessing pipeline and predictive modeling built for statistical analysis 
                  and classification tasks. Features Pandas cleaning, feature normalization, and Scikit-learn model evaluation.
                </p>

                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem', marginBottom: '2rem' }}>
                  {['Python', 'Pandas', 'Scikit-Learn', 'Matplotlib', 'Classification'].map((tag) => (
                    <span key={tag} className="tech-tag">{tag}</span>
                  ))}
                </div>

                <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
                  <button
                    onClick={() => setSelectedProject(projectsData[2])}
                    className="btn btn-outline"
                    style={{ padding: '0.7rem 1.4rem', fontSize: '0.9rem' }}
                  >
                    <span>Inspect Pipeline</span>
                    <ArrowRight size={16} />
                  </button>

                  <a
                    href="https://github.com/niraj0050/ML-Mini-Project"
                    target="_blank"
                    rel="noreferrer"
                    className="btn btn-primary"
                    style={{ padding: '0.7rem 1.4rem', fontSize: '0.9rem' }}
                  >
                    <Github size={17} />
                    <span>View GitHub Code</span>
                  </a>
                </div>
              </div>
            </div>

          </div>

          <div style={{ textAlign: 'center', marginTop: '4rem' }}>
            <NavLink to="/projects" className="btn btn-outline" style={{ padding: '0.95rem 2.2rem' }}>
              <span>Explore All Projects & Architecture</span>
              <ArrowRight size={18} />
            </NavLink>
          </div>
        </div>
      </section>

      {/* SECTION 4: KEY SKILLS SNAPSHOT */}
      <section 
        className="section" 
        style={{ 
          background: 'var(--bg-secondary)', 
          borderTop: '1px solid var(--border-color)', 
          borderBottom: '1px solid var(--border-color)' 
        }}
      >
        <div className="container">
          <SectionHeader
            badge="Verified Competencies"
            title="Core Technical Proficiencies"
            subtitle="Categorized programming languages, web frameworks, database engines, and software engineering tools."
          />

          <div 
            style={{ 
              display: 'flex', 
              flexWrap: 'wrap', 
              gap: '1rem', 
              justifyContent: 'center', 
              maxWidth: '920px', 
              margin: '0 auto 3rem auto' 
            }}
          >
            {[
              { name: 'React.js 18', group: 'Frontend' },
              { name: 'Three.js & WebGL', group: '3D' },
              { name: 'JavaScript (ES6+)', group: 'Core' },
              { name: 'PHP & Apache', group: 'Backend' },
              { name: 'Python 3', group: 'Core' },
              { name: 'MySQL Relational', group: 'Database' },
              { name: 'Node.js & Express', group: 'Backend' },
              { name: 'Tkinter GUI', group: 'Desktop' },
              { name: 'Pandas & ML', group: 'Data' },
              { name: 'Git & GitHub', group: 'DevOps' },
              { name: 'WordPress', group: 'CMS' },
              { name: 'HTML5 & CSS3', group: 'Frontend' }
            ].map((skill) => (
              <div
                key={skill.name}
                className="glass-card"
                style={{ 
                  padding: '0.85rem 1.5rem', 
                  display: 'flex', 
                  alignItems: 'center', 
                  gap: '0.75rem', 
                  fontWeight: 600, 
                  fontSize: '0.95rem' 
                }}
              >
                <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: 'var(--accent-orange)' }}></div>
                <span>{skill.name}</span>
                <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                  {skill.group}
                </span>
              </div>
            ))}
          </div>

          <div style={{ textAlign: 'center' }}>
            <NavLink to="/skills" className="btn btn-outline">
              <span>View In-Depth Skills Matrix</span>
              <ArrowRight size={16} />
            </NavLink>
          </div>
        </div>
      </section>

      {/* SECTION 5: HIGH-IMPACT CONTACT CTA BANNER */}
      <section className="section">
        <div className="container">
          <div 
            className="glass-card" 
            style={{ 
              padding: '4.5rem 2.5rem', 
              textAlign: 'center', 
              background: 'radial-gradient(circle at center, rgba(255, 107, 0, 0.14) 0%, rgba(13, 16, 24, 0.95) 85%)', 
              border: '1px solid var(--border-accent)',
              borderRadius: 'var(--radius-xl)',
              boxShadow: '0 30px 60px rgba(0, 0, 0, 0.6), 0 0 40px rgba(255, 107, 0, 0.15)'
            }}
          >
            <div 
              style={{ 
                display: 'inline-flex', 
                alignItems: 'center', 
                gap: '0.6rem', 
                padding: '0.4rem 1.2rem', 
                borderRadius: 'var(--radius-full)', 
                background: 'rgba(255, 107, 0, 0.12)', 
                border: '1px solid var(--border-accent)',
                color: 'var(--accent-orange)', 
                fontSize: '0.82rem', 
                fontWeight: 600, 
                marginBottom: '1.5rem' 
              }}
            >
              <Sparkles size={15} />
              <span>Available For Opportunities</span>
            </div>

            <h2 
              style={{ 
                fontSize: 'clamp(2rem, 4vw, 3rem)', 
                marginBottom: '1.25rem', 
                fontWeight: 800,
                letterSpacing: '-0.02em'
              }}
            >
              Let's Build Something <span className="gradient-text">Exceptional Together</span>.
            </h2>

            <p 
              style={{ 
                fontSize: '1.1rem', 
                maxWidth: '640px', 
                margin: '0 auto 2.5rem auto', 
                color: 'var(--text-secondary)',
                lineHeight: '1.75'
              }}
            >
              Seeking an ambitious Full Stack Web Developer intern or junior software engineer in Surat, Vapi, Valsad, or remote? 
              I am ready to contribute from day one.
            </p>

            <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap' }}>
              <NavLink 
                to="/contact" 
                className="btn btn-primary" 
                style={{ padding: '1rem 2.4rem', fontSize: '1rem' }}
              >
                <span>Get In Touch</span>
                <ArrowRight size={18} />
              </NavLink>

              <a 
                href={`mailto:${personalData.email}`} 
                className="btn btn-outline"
                style={{ padding: '1rem 2rem', fontSize: '1rem' }}
              >
                <span>Email Me Directly</span>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Case Study Modal */}
      <ProjectModal project={selectedProject} onClose={() => setSelectedProject(null)} />
    </div>
  );
}
